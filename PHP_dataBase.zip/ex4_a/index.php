<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php 
$link = mysqli_connect("localhost", "root", "", "phppractice");
  
if ($link == false) {
    die("ERROR: Could not connect. "
                .mysqli_connect_error());
}

echo "<p>Rezultat : </p>";
echo "<br>";  
$sql = "SELECT f.TITLU, f.ID_PRODUCATOR, f.STUDIO_NUME, s.NUME, s.ADRESA, s.TARA,  p.ID_PERSOANA, p.NUME, p.ADRESA, p.SEX, p.CASTIG_NET, p.DATA_NASTERII, p.MONEDA
FROM film f
INNER JOIN studio s
ON f.STUDIO_NUME = s.NUME AND f.TITLU = 'Iron Man 3'
INNER JOIN persoana p
ON f.ID_PRODUCATOR = p.ID_PERSOANA AND f.TITLU = 'Iron Man 3'";
if ($res = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($res) > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>Titlu</th>";
        echo "<th>Nume studio</th>";
        echo "<th>Adresa studio</th>";
        echo "<th>Tara</th>";
        echo "<th>Nume producator</th>";
        echo "<th>Adresa producator</th>";
        echo "<th>Sex</th>";
        echo "<th>Castig net</th>";
        echo "<th>Data nasterii</th>";
        echo "<th>Moneda</th>";
        echo "</tr>";
        while ($row = mysqli_fetch_array($res)) {
            echo "<tr>";
            echo "<td>".$row['TITLU']."</td>";
            echo "<td>".$row['STUDIO_NUME']."</td>";
            echo "<td>".$row['ADRESA']."</td>";
            echo "<td>".$row['TARA']."</td>";
            echo "<td>".$row['NUME']."</td>";
            echo "<td>".$row['ADRESA']."</td>";
            echo "<td>".$row['SEX']."</td>";
            echo "<td>".$row['CASTIG_NET']."</td>";
            echo "<td>".$row['DATA_NASTERII']."</td>";
            echo "<td>".$row['MONEDA']."</td>";
            echo "</tr>";
        }
        echo "</table>";
        
    }
    else {
        echo "No matching records are found.";
    }
}
else {
    echo "ERROR: Could not able to execute $sql. "
                                .mysqli_error($link);
}
mysqli_close($link);
?>


<a href="http://localhost/website/">
       <button type="button">Return </button>
     </a>
</body>
</html>