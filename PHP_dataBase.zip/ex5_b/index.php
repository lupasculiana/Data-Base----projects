<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php 
$link = mysqli_connect("localhost", "root", "", "phppractice");
  
if ($link == false) {
    die("ERROR: Could not connect. "
                .mysqli_connect_error());
}

echo "<p>Rezultat : </p>";
echo "<br>";  
$sql = "SELECT *
FROM film
ORDER BY durata DESC, an ASC";
if ($res = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($res) > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>Durata</th>";
        echo "<th>An</th>";
        echo "<th>Titlu</th>";
        echo "<th>Gen</th>";
        echo "<th>Nume studio</th>";
        echo "<th>Id producator</th>";
        echo "</tr>";
        if ($row = mysqli_fetch_array($res)) {
	    $size = sizeof($row);
	    for ($x = $size; $x <= $size; $x++) {
   	    echo "<tr>";
            echo "<td>".$row['DURATA']."</td>";
            echo "<td>".$row['AN']."</td>";
            echo "<td>".$row['TITLU']."</td>";
            echo "<td>".$row['GEN']."</td>";
            echo "<td>".$row['STUDIO_NUME']."</td>";
            echo "<td>".$row['ID_PRODUCATOR']."</td>";
            echo "</tr>";
	    }
        }
        echo "</table>";
        
    }
    else {
        echo "No matching records are found.";
    }
}
else {
    echo "ERROR: Could not able to execute $sql. "
                                .mysqli_error($link);
}
mysqli_close($link);
?>

<a href="http://localhost/website/">
       <button type="button">Return </button>
     </a>
</body>
</html>