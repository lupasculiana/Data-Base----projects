<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php 
$link = mysqli_connect("localhost", "root", "", "phppractice");
  
if ($link == false) {
    die("ERROR: Could not connect. "
                .mysqli_connect_error());
}

echo "<p>Rezultat : </p>";
echo "<br>";  
$sql = "SELECT
   a1.TITLU_FILM,
   a2.TITLU_FILM,
  a1.ID_ACTOR,
  a2.ID_ACTOR, 
  p1.ID_PERSOANA,
  p1.SEX,
  p1.NUME,
  p2.SEX,
  p2.ID_PERSOANA,
  P2.NUME
FROM
    distributie a1
INNER JOIN distributie a2 ON
    a1.TITLU_FILM = a2.TITLU_FILM
    AND a1.ID_ACTOR != a2.ID_ACTOR
INNER JOIN persoana p1
ON a1.ID_ACTOR = p1.ID_PERSOANA AND p1.SEX = 'F'
INNER JOIN persoana p2
ON a2.ID_ACTOR = p2.ID_PERSOANA AND p2.SEX = 'M'";
if ($res = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($res) > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>Titlu film</th>";
        echo "<th>Nume actor</th>";
        echo "<th>Nume actrita</th>";
        echo "</tr>";
        while($row = mysqli_fetch_array($res)) {
        echo "<td>".$row['TITLU_FILM']."</td>";
	if($row['SEX'] == 'F'){
            echo "<td>".$row['NUME']."</td>";
        }
        elseif($row['SEX'] == 'M'){
            echo "<td>".$row['NUME']."</td>";
        }
echo "</tr>";
        }
        echo "</table>";
        
    }
    else {
        echo "No matching records are found.";
    }
}
else {
    echo "ERROR: Could not able to execute $sql. "
                                .mysqli_error($link);
}
mysqli_close($link);
?>

<a href="http://localhost/website/">
       <button type="button">Return </button>
     </a>
</body>
</html>