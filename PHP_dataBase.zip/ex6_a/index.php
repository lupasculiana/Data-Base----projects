<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php 
$link = mysqli_connect("localhost", "root", "", "phppractice");
  
if ($link == false) {
    die("ERROR: Could not connect. "
                .mysqli_connect_error());
}

echo "<p>Rezultat : </p>";
echo "<br>";  
$sql = "SELECT ID_ACTOR, COUNT(*) AS 'Numar de filme comedie'
FROM distributie
WHERE EXISTS(SELECT *
             FROM film 
             WHERE distributie.TITLU_FILM=film.TITLU AND film.GEN = 'comedie')
GROUP BY ID_ACTOR";
if ($res = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($res) > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>Id actor</th>";
        echo "<th>Numar filme comedie</th>";
        echo "</tr>";
        while ($row = mysqli_fetch_array($res)) {
            echo "<tr>";
            echo "<td>".$row['ID_ACTOR']."</td>";
            echo "<td>".$row['Numar de filme comedie']."</td>";
            echo "</tr>";
        }
        echo "</table>";
        
    }
    else {
        echo "No matching records are found.";
    }
}
else {
    echo "ERROR: Could not able to execute $sql. "
                                .mysqli_error($link);
}
mysqli_close($link);
?>


<a href="http://localhost/website/">
       <button type="button">Return </button>
     </a>
</body>
</html>