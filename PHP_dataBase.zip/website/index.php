<!DOCTYPE html>
<html>
<body>

<h1>Meniu</h1>

<a href="http://localhost/ex3_a/">
       <button type="button">Ex. 3 a)</button>
     </a>
<br>
<a href="http://localhost/ex3_b/">
       <button type="button">Ex. 3 b)</button>
     </a>
<br>
<a href="http://localhost/ex4_a/">
       <button type="button">Ex. 4 a)</button>
     </a>
<br>
<a href="http://localhost/ex4_b/">
       <button type="button">Ex. 4 b)</button>
     </a>
<br>
<a href="http://localhost/ex5_a/">
       <button type="button">Ex. 5 a)</button>
     </a>
<br>
<a href="http://localhost/ex5_b/">
       <button type="button">Ex. 5 b)</button>
     </a>
<br>
<a href="http://localhost/ex6_a/">
       <button type="button">Ex. 6 a)</button>
     </a>
<br>
<a href="http://localhost/ex6_b/">
       <button type="button">Ex. 6 b)</button>
     </a>
 
</body>
</html>
