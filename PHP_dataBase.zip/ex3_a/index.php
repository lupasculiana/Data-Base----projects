<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<div class="row">
    <form class="col s12" method="POST" action="" accept-charset="utf-8">
        <div class="row">
            <div class="input-field col s6">
                <input placeholder="MovieType" id="movieT" type="text" name="movieT" />
                <input type="submit" value="Introduceti tipul filmului" />
            </div>
        </div>
    </form>
</div>


 <?php 
$link = mysqli_connect("localhost", "root", "", "phppractice");
  
if ($link == false) {
    die("ERROR: Could not connect. "
                .mysqli_connect_error());
}

$movieT = $_REQUEST['movieT'];
echo "<p>Rezultat : </p>";
echo "<br>";  
$sql = sprintf("SELECT AN, TITLU, GEN FROM film WHERE GEN = '%s' AND AN > 1990", mysqli_real_escape_string($link, $movieT));
if ($res = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($res) > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>An</th>";
        echo "<th>Titlu</th>";
        echo "<th>Gen</th>";
        echo "</tr>";
        while ($row = mysqli_fetch_array($res)) {
            echo "<tr>";
            echo "<td>".$row['AN']."</td>";
            echo "<td>".$row['TITLU']."</td>";
            echo "<td>".$row['GEN']."</td>";
            echo "</tr>";
        }
        echo "</table>";
        
    }
    else {
        echo "No matching records are found.";
    }
}
else {
    echo "ERROR: Could not able to execute $sql. "
                                .mysqli_error($link);
}
mysqli_close($link);
?>

<a href="http://localhost/website/">
       <button type="button">Return </button>
     </a>
</body>
</html>
