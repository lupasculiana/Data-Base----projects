DELETE FROM film
WHERE EXISTS
  ( SELECT distributie.titlu_film
    FROM distributie
    WHERE distributie.id_actor = null );