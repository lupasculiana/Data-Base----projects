BEGIN
INSERT INTO persoana (id_persoana, nume, adresa, sex, data_nasterii, castig_net, moneda)
VALUES (26, 'Gwyneth Paltrow', 'Los Angeles', 'F', TO_DATE('1972/09/27 ', 'yyyy/mm/dd '),5000,'USD');

INSERT INTO distributie (titlu_film, an_film, id_actor)
VALUES ('Iron Man 3', 2013, 26);
END;


SELECT distributie.id_actor, persoana.id_persoana, persoana.nume, persoana.sex, id_actor "a1", id_actor "a2"
FROM distributie
INNER JOIN persoana
ON distributie.id_actor = persoana.id_persoana AND persoana.sex='M' OR persoana.sex='F';


SELECT
   a1.titlu_film,
  (a1.id_actor) actor1,
  (a2.id_actor) actor2  
FROM
    distributie a1
INNER JOIN distributie a2 ON
    a1.sex='F'
    AND a2.sex='M' 
    AND a1.titlu_film = a2.titlu_film
ORDER BY  
   a1.titlu_film DESC,
   actor1, 
   actor2;