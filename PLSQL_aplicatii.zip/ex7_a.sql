
BEGIN
INSERT INTO persoana (id_persoana, nume, adresa, sex, data_nasterii, castig_net, moneda)
VALUES (22, 'Humphrey Bogart', 'Los Angeles', 'M', TO_DATE('1899/12/25 ', 'yyyy/mm/dd '),1000,'USD');

INSERT INTO persoana (id_persoana, nume, adresa, sex, data_nasterii, castig_net, moneda)
VALUES (3, 'Ann Sarnoff', 'San Francisco', 'F', TO_DATE('1961/11/10 ', 'yyyy/mm/dd '),250,'USD');

INSERT INTO persoana (id_persoana, nume, adresa, sex, data_nasterii, castig_net, moneda)
VALUES (11, 'Hal B. Wallis', 'Los Angeles', 'M', TO_DATE('1898/09/14 ', 'yyyy/mm/dd '),800,'USD');

INSERT INTO film (durata, an, titlu, gen, studio_nume, id_producator)
VALUES (100, 1941,'The Maltese Falcon', 'drama', 'Warner Bros.', 11);

INSERT INTO distributie (titlu_film, an_film, id_actor)
VALUES ('The Maltese Falcon', 1941, 22);
END;
