ALTER TABLE film
ADD CONSTRAINT check_type
  CHECK (gen IN ('drama','comedie','SF','copii'));

ALTER TABLE studio
ADD CONSTRAINT check_correct 
 CHECK ((tara ='Romania' AND adresa = 'Buftea') OR (adresa != 'Buftea'));