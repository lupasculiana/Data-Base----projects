BEGIN
INSERT INTO persoana (id_persoana, nume, adresa, sex, data_nasterii, castig_net, moneda)
VALUES (25, 'Robert Downey Jr', 'New York', 'M', TO_DATE('1965/04/04 ', 'yyyy/mm/dd '),6000,'USD');

INSERT INTO persoana (id_persoana, nume, adresa, sex, data_nasterii, castig_net, moneda)
VALUES (15, 'Shane Black', 'Pennsylvania', 'M', TO_DATE('1961/12/16 ', 'yyyy/mm/dd '),9800,'USD');

INSERT INTO film (durata, an, titlu, gen, studio_nume, id_producator)
VALUES (130, 2013,'Iron Man 3', 'SF', 'Warner Bros.', 15);

INSERT INTO distributie (titlu_film, an_film, id_actor)
VALUES ('Iron Man 3', 2013, 25);
END;


SELECT film.titlu, film.studio_nume, studio.nume, studio.adresa, studio.tara
FROM film
INNER JOIN studio
ON film.studio_nume = studio.nume AND film.titlu = 'Iron Man 3';

SELECT film.titlu, film.id_producator, persoana.id_persoana, persoana.nume, persoana.adresa, persoana.sex, persoana.castig_net, persoana.data_nasterii, persoana.moneda
FROM film
INNER JOIN persoana
ON film.id_producator = persoana.id_persoana AND film.titlu = 'Iron Man 3';