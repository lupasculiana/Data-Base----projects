SELECT *
FROM film
ORDER BY durata DESC, an ASC
FETCH  first 1 rows only;
