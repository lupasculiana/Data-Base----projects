SELECT id_actor, COUNT(*) AS "Numar de filme comedie"
FROM distributie
WHERE EXISTS(SELECT *
             FROM film 
             WHERE distributie.titlu_film=film.titlu AND film.gen = 'SF')
GROUP BY id_actor;