SELECT MAX(castig_net) AS "Castig maxim"
FROM persoana
WHERE EXISTS(SELECT *
             FROM studio
             WHERE studio.id_presedinte=persoana.id_persoana);
