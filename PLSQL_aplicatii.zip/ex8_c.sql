CREATE or REPLACE VIEW filme_copii_disneyy AS
  SELECT film.titlu,film.an,film.gen,film.durata,film.id_producator,film.studio_nume,persoana.id_persoana,persoana.adresa,persoana.sex,persoana.data_nasterii,persoana.castig_net,persoana.moneda,persoana.nume
  FROM film
  INNER JOIN persoana
  ON film.id_producator = persoana.id_persoana
  WHERE film.studio_nume = 'Disney' AND gen='comedie';

CREATE OR REPLACE TRIGGER new_movie_trigger
INSTEAD OF INSERT OR UPDATE ON filme_copii_disneyy
DECLARE
v_titlu film.titlu%TYPE := NULL;
v_nume persoana.nume%TYPE := NULL;
BEGIN
SELECT DISTINCT titlu INTO v_titlu
FROM film
WHERE
titlu = :NEW.titlu;
IF v_nume IS NULL THEN
 INSERT INTO film(titlu, gen, an ,durata) 
 VALUES(:NEW.titlu,:NEW.gen,:NEW.an,:NEW.durata);
END IF;

SELECT DISTINCT nume INTO v_nume 
FROM persoana
WHERE nume = :NEW.id_producator;
IF v_nume IS NULL THEN
  INSERT INTO persoana(id_persoana, adresa, sex, nume ,data_nasterii, castig_net, moneda)
  VALUES(:NEW.id_persoana, :NEW.adresa, :NEW.sex, :NEW.nume, :NEW.data_nasterii, :NEW.castig_net, :NEW.moneda);
END IF;
END;