
SELECT an, titlu, gen
FROM filme
WHERE gen = 'SF'
AND an > 1990
ORDER BY an ASC, titlu ASC;

SELECT nume, sex, castig_net, moneda
FROM persoana
WHERE sex = 'F'
AND moneda = 'USD'
AND castig_net > 1000000
ORDER BY nume ASC;