CREATE OR REPLACE TRIGGER change_salary
AFTER INSERT ON distributie FOR EACH ROW 
DECLARE 
CURSOR cursor_c  IS SELECT id_producator FROM film WHERE titlu=:NEW.titlu_film;
v_id Film.id_producator%TYPE;
BEGIN 
OPEN cursor_c;
FETCH cursor_c INTO v_id;
IF (:NEW.id_actor = v_id) THEN
UPDATE persoana 
SET persoana.castig_net = persoana.castig_net * 1.02
WHERE persoana.id_persoana = :NEW.id_actor;
ELSE
UPDATE persoana 
SET persoana.castig_net = persoana.castig_net * 1.01
WHERE persoana.id_persoana = :NEW.id_actor;
END IF;
CLOSE cursor_c;
END;