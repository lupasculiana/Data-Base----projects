
SELECT 
    titlu,
    an,
    COUNT(*)
FROM 
    film
DELETE
FROM
    film
WHERE
    HAVING COUNT(*) > 1;