CREATE TABLE film
( durata number(10) NOT NULL,
  an number(10) ,
  titlu varchar2(50),
  gen varchar2(50) CHECK (gen IN ('drama','comedie','SF','copii')),
  studio_nume varchar(50),
  id_producator number(10),
  PRIMARY KEY (titlu, an),
  FOREIGN KEY (id_producator)
    REFERENCES persoana(id_persoana),
  FOREIGN KEY (studio_nume)
    REFERENCES studio(nume)
);