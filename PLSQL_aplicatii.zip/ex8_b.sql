CREATE OR REPLACE TRIGGER prevent_change
AFTER UPDATE ON persoana FOR EACH ROW 
DECLARE 
CURSOR cursor_l  IS SELECT id_presedinte FROM studio WHERE id_presedinte=:NEW.id_persoana;
v_id studio.id_presedinte%TYPE;
BEGIN 
OPEN cursor_l;
FETCH cursor_l INTO v_id;
IF (:NEW.id_persoana = v_id) THEN
UPDATE persoana 
SET castig_net = :OLD.castig_net;
ELSE
UPDATE persoana 
SET castig_net = :NEW.castig_net;
END IF;
CLOSE cursor_l;
END;