ALTER TABLE persoana
  ADD email varchar2(45);