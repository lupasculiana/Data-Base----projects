ALTER TABLE film
ADD CONSTRAINT film_unique UNIQUE (an, titlu);