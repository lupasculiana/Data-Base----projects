BEGIN
INSERT INTO persoana (id_persoana, nume, adresa, sex, data_nasterii, castig_net, moneda)
VALUES (12, 'Christopher Nolan', 'Sheffield', 'M', TO_DATE('1970/09/30 ', 'yyyy/mm/dd '),4000,'GBP');
END;


UPDATE persoana
SET moneda = 'USD',
    castig_net = castig_net * 1.33
WHERE moneda = 'GBP';