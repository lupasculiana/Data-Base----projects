INSERT INTO persoana (id_persoana, nume, adresa, sex, data_nasterii, castig_net, moneda)
VALUES (37, 'Angelina Jolie', 'Los Angeles', 'F', TO_DATE('1975/06/04 ', 'yyyy/mm/dd '),20000,'USD');

INSERT INTO film (durata, an, titlu, gen, studio_nume, id_producator)
VALUES (132, 2015,'By the Sea', 'drama', 'Warner Bros.', 37);

INSERT INTO distributie (titlu_film, an_film, id_actor)
VALUES ('By the Sea', 2015, 37);

SELECT *
FROM film
WHERE EXISTS (SELECT *
              FROM distributie
              WHERE distributie.id_actor = film.id_producator);